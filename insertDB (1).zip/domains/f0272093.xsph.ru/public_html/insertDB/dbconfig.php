<?php

    $host = '10.0.0.57';

    $dbname = 'f0272093_app_wordpress_0';

    $username = 'f0272093_app_wordpress_0';

    $password = '84zTE7Rit8';
